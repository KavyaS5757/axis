# HackVerse 2023 Website

<img src="/img/logo.webp" width=240px alt="HackVerse 4.0">

HackVerse is a 24 hour nation-wide hackathon organized at National Institute of Technology, Karnataka, Surathkal. 2023 will see the 4th edition of one of the biggest student run hackathons in India
